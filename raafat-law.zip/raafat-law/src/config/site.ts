// ملف الإعدادات المركزي: غيّر بيانات المكتب من هنا فقط
export const site = {
  name: "الأستاذ رأفت خضر",
  title: "المحامي بالنقض",
  url: "https://example.com", // TODO: ضع الدومين الفعلي
  city: "مدينة 6 أكتوبر – الجيزة – مصر",
  whatsapp: "201116767345",
  phoneDisplay: "01116767345",
  email: "", // يضاف لاحقًا
  mapUrl: "", // TODO: رابط Google Maps لاحقًا
  waMessage: "السلام عليكم، أرغب في الحصول على استشارة قانونية من مكتب الأستاذ رأفت خضر المحامي بالنقض.",
};
export const waLink = (msg = site.waMessage) => `https://wa.me/${site.whatsapp}?text=${encodeURIComponent(msg)}`;
export const nav = [["/", "الرئيسية"],["/services", "خدماتنا"],["/contact", "اتصل بنا"]] as const;
