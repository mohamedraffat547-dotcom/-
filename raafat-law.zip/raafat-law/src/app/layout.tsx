import type { Metadata } from "next";
import { Cairo } from "next/font/google";
import "./globals.css";
import { site } from "@/config/site";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import WhatsAppFloat from "@/components/WhatsAppFloat";
const cairo = Cairo({ subsets: ["arabic","latin"], weight: ["400","600","800"], variable: "--font-cairo", display: "swap" });
export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: `${site.name} ${site.title} | محامي أحوال شخصية وقضايا مدنية في 6 أكتوبر`, template: `%s | ${site.name} ${site.title}` },
  description: "مكتب محاماة في 6 أكتوبر والجيزة متخصص في قضايا الأحوال الشخصية والأسرة والقضايا المدنية وفق القوانين المصرية.",
  alternates: { canonical: "/" },
  openGraph: { type: "website", locale: "ar_EG", siteName: `${site.name} ${site.title}` },
};
const ld = { "@context":"https://schema.org","@type":"LegalService",name:`${site.name} ${site.title}`,url:site.url,telephone:`+${site.whatsapp}`,
  areaServed:["6 أكتوبر","الشيخ زايد","الجيزة"],address:{"@type":"PostalAddress",addressLocality:"6 أكتوبر",addressRegion:"الجيزة",addressCountry:"EG"}};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="ar" dir="rtl"><body className={`${cairo.variable} font-sans`}>
    <script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify(ld)}} />
    <Header /><main>{children}</main><Footer /><WhatsAppFloat /></body></html>);
}
