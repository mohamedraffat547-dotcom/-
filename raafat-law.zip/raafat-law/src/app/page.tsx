import Link from "next/link";
import { Gavel, Users, ShieldCheck, Lock, FileSearch, ListChecks } from "lucide-react";
import { waLink } from "@/config/site";
const why = [[FileSearch,"دراسة قانونية دقيقة لكل حالة"],[ShieldCheck,"الاهتمام بحقوق العملاء"],[ListChecks,"وضوح في شرح الإجراءات"],[Lock,"المحافظة على سرية المعلومات"],[Gavel,"متابعة الإجراءات القانونية"]] as const;
const cards = [["الأحوال الشخصية والأسرة","طلاق، خلع، نفقة، حضانة، رؤية، نسب، مواريث وغيرها.","/services#family"],["القضايا المدنية","تعويضات، ديون، عقود، ملكية، إيجارات، طرد وإخلاء.","/services#civil"]];
export default function Home() {
  return (<>
    <section className="bg-navy text-white"><div className="mx-auto max-w-6xl px-4 py-20 md:py-28">
      <h1 className="text-4xl md:text-6xl font-extrabold leading-tight">الأستاذ رأفت خضر<br /><span className="text-gold">المحامي بالنقض</span></h1>
      <p className="mt-4 text-xl text-gold">خبرة قانونية.. رؤية واضحة.. دفاع عن الحقوق.</p>
      <p className="mt-4 max-w-2xl text-white/85 leading-8">نقدم خدمات قانونية متخصصة في قضايا الأحوال الشخصية والقضايا المدنية، مع الاهتمام بدراسة كل حالة على حدة ومتابعة الإجراءات القانونية وفقًا للقوانين المصرية.</p>
      <div className="mt-8 flex flex-wrap gap-3"><Link href="/contact" className="bg-gold text-navy font-bold px-6 py-3 rounded min-h-11">اطلب استشارة قانونية</Link>
        <a href={waLink()} target="_blank" rel="noopener noreferrer" className="border border-gold text-gold px-6 py-3 rounded min-h-11">تواصل عبر واتساب</a></div></div></section>
    <section className="mx-auto max-w-6xl px-4 mt-12 grid gap-6 md:grid-cols-2">
      {cards.map(([t,d,h])=><Link key={h} href={h} className="block bg-white border-t-4 border-gold p-8 rounded shadow hover:shadow-lg"><Users className="text-gold" aria-hidden /><h2 className="text-2xl font-bold text-navy mt-3">{t}</h2><p className="mt-2">{d}</p></Link>)}</section>
    <section className="mx-auto max-w-6xl px-4 mt-16"><h2 className="text-3xl font-bold text-navy">لماذا تختار مكتبنا؟</h2>
      <ul className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{why.map(([I,t])=><li key={t} className="flex items-center gap-3 bg-white p-4 rounded"><I className="text-gold shrink-0" aria-hidden />{t}</li>)}</ul></section>
    <section className="mx-auto max-w-6xl px-4 mt-16 bg-navy text-white rounded p-10 text-center"><h2 className="text-2xl font-bold">هل لديك استفسار قانوني؟</h2>
      <p className="mt-2 text-white/80">اشرح حالتك باختصار ونرد عليك عبر واتساب.</p><Link href="/contact" className="inline-block mt-5 bg-gold text-navy font-bold px-6 py-3 rounded">اتصل بنا</Link></section></>);
}
