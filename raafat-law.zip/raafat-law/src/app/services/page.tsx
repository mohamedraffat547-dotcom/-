import type { Metadata } from "next";
import { family, civil, type Service } from "@/data/services";
export const metadata: Metadata = { title: "خدماتنا القانونية", description: "خدمات الأحوال الشخصية والقضايا المدنية في 6 أكتوبر والجيزة.", alternates: { canonical: "/services" } };
const Group = ({ id, h, items }: { id: string; h: string; items: Service[] }) => (<section id={id} className="mt-12 scroll-mt-24"><h2 className="text-3xl font-bold text-navy">{h}</h2>
  <div className="mt-6 grid gap-4 md:grid-cols-2">{items.map(s => <article key={s.slug} id={s.slug} className="bg-white p-5 rounded border-s-4 border-gold"><h3 className="font-bold text-navy text-lg">{s.title}</h3><p className="mt-1">{s.desc}</p></article>)}</div></section>);
export default function Services() {
  return (<div className="mx-auto max-w-6xl px-4 py-12"><h1 className="text-4xl font-extrabold text-navy">خدماتنا القانونية</h1>
    <p className="mt-3 max-w-2xl">للحصول على تفاصيل حالتك والمستندات المطلوبة، تواصل معنا لطلب استشارة.</p>
    <Group id="family" h="الأحوال الشخصية والأسرة" items={family} /><Group id="civil" h="القضايا المدنية" items={civil} /></div>);
}
