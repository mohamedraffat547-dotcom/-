import type { Metadata } from "next";
import ContactForm from "@/components/ContactForm";
import { site } from "@/config/site";
export const metadata: Metadata = { title: "اتصل بنا", alternates: { canonical: "/contact" } };
export default function Contact() {
  return (<div className="mx-auto max-w-2xl px-4 py-12"><h1 className="text-4xl font-extrabold text-navy mb-2">اتصل بنا</h1><p className="mb-6">{site.city}</p><ContactForm />
    <p className="mt-6 text-sm">{site.mapUrl ? <a href={site.mapUrl} className="text-navy underline">الموقع على الخريطة</a> : "رابط الخريطة سيُضاف لاحقًا من ملف الإعدادات."}</p></div>);
}
