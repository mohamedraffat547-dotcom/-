import type { MetadataRoute } from "next";
import { site } from "@/config/site";
export default function sitemap(): MetadataRoute.Sitemap { return ["","/services","/contact","/privacy"].map(p => ({ url: site.url + p })); }
