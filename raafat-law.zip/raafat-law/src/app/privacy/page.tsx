export const metadata = { title: "سياسة الخصوصية", alternates: { canonical: "/privacy" } };
export default function Privacy() {
  return (<div className="mx-auto max-w-3xl px-4 py-12 leading-8"><h1 className="text-4xl font-extrabold text-navy">سياسة الخصوصية</h1>
    <p className="mt-4">لا يجمع هذا الموقع بيانات شخصية غير ضرورية، ولا يعرض بيانات العملاء. نموذج التواصل لا يحفظ بياناتك على الموقع؛ فهو يجهّز رسالة واتساب ترسلها بنفسك. يُرجى عدم كتابة تفاصيل حساسة في الرسالة الأولى. المعلومات المنشورة للتوعية العامة وليست بديلًا عن استشارة قانونية خاصة.</p></div>);
}
