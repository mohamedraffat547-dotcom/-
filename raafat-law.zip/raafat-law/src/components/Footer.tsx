import Link from "next/link";
import { nav, site, waLink } from "@/config/site";
export default function Footer() {
  return (<footer className="bg-navy text-white/80 mt-16"><div className="mx-auto max-w-6xl px-4 py-10 grid gap-8 md:grid-cols-3 text-sm">
    <div><b className="text-white text-lg">{site.name}</b><p className="text-gold">{site.title}</p><p className="mt-2">{site.city}</p></div>
    <div><b className="text-white">الصفحات</b><ul className="mt-2 space-y-1">{nav.map(([h,l])=><li key={h}><Link href={h}>{l}</Link></li>)}<li><Link href="/privacy">سياسة الخصوصية</Link></li></ul></div>
    <div><b className="text-white">تواصل</b><p className="mt-2"><a href={waLink()} className="text-gold">واتساب: <span dir="ltr">{site.phoneDisplay}</span></a></p></div>
    </div><p className="border-t border-white/10 text-center text-xs py-4 px-4">المعلومات المنشورة للتوعية العامة وليست بديلًا عن استشارة قانونية خاصة.</p></footer>);
}
