import Link from "next/link";
import { Scale } from "lucide-react";
import { nav, site } from "@/config/site";
export default function Header() {
  return (<header className="bg-navy text-white sticky top-0 z-40">
    <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between gap-4">
      <Link href="/" className="flex items-center gap-3"><Scale className="text-gold" size={30} aria-hidden />
        <span className="leading-tight"><b className="block">{site.name}</b><span className="text-gold text-sm">{site.title}</span></span></Link>
      <nav aria-label="التنقل الرئيسي" className="flex flex-wrap gap-x-5 gap-y-1 text-sm">
        {nav.map(([h,l]) => <Link key={h} href={h} className="hover:text-gold py-2">{l}</Link>)}</nav>
    </div></header>);
}
