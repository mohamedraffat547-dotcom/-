"use client";
import { useState } from "react";
import { site, waLink } from "@/config/site";
const types = ["أحوال شخصية وأسرة","قضايا مدنية","أخرى"];
export default function ContactForm() {
  const [err, setErr] = useState<Record<string,string>>({}); const [done, setDone] = useState(false);
  function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); const f = new FormData(e.currentTarget);
    if (f.get("website")) return; // honeypot ضد الرسائل العشوائية
    const name = String(f.get("name")||"").trim(), phone = String(f.get("phone")||"").replace(/[\s-]/g,""), type = String(f.get("type")||""), msg = String(f.get("msg")||"").trim();
    const er: Record<string,string> = {};
    if (name.length < 3) er.name = "اكتب اسمك (3 أحرف على الأقل).";
    if (!/^(\+?20|0)?1[0125]\d{8}$/.test(phone)) er.phone = "اكتب رقم موبايل مصري صحيح مثل 01xxxxxxxxx.";
    if (!type) er.type = "اختر نوع القضية.";
    if (msg.length < 10) er.msg = "اكتب وصفًا مختصرًا (10 أحرف على الأقل) دون بيانات حساسة.";
    setErr(er); if (Object.keys(er).length) return;
    window.open(waLink(`السلام عليكم، أنا ${name}. نوع الاستفسار: ${type}. ${msg}. رقمي: ${phone}`), "_blank", "noopener");
    setDone(true);
  }
  const base = "w-full rounded border border-navy/30 bg-white px-3 py-3";
  const E = ({k}:{k:string}) => err[k] ? <p role="alert" className="text-red-700 text-sm mt-1">{err[k]}</p> : null;
  return (<form onSubmit={onSubmit} noValidate className="space-y-4 bg-white p-6 rounded shadow">
    <input name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden />
    <div><label htmlFor="name" className="font-semibold">الاسم</label><input id="name" name="name" className={base} /><E k="name" /></div>
    <div><label htmlFor="phone" className="font-semibold">رقم الهاتف</label><input id="phone" name="phone" inputMode="tel" dir="ltr" className={`${base} text-end`} /><E k="phone" /></div>
    <div><label htmlFor="type" className="font-semibold">نوع القضية</label><select id="type" name="type" defaultValue="" className={base}><option value="" disabled>اختر</option>{types.map(t=><option key={t}>{t}</option>)}</select><E k="type" /></div>
    <div><label htmlFor="msg" className="font-semibold">وصف مختصر للاستفسار</label><textarea id="msg" name="msg" rows={4} className={base} /><E k="msg" /></div>
    <button className="bg-gold text-navy font-bold px-6 py-3 rounded min-h-11">أرسل الاستفسار عبر واتساب</button>
    {done && <p role="status" className="text-green-800">تم تجهيز رسالتك في واتساب لإرسالها إلى المكتب. لم تُحفظ أي بيانات على الموقع.</p>}
    <p className="text-xs text-ink/70">لا يوجد خادم لاستقبال الرسائل حاليًا؛ الإرسال يتم عبر واتساب {site.phoneDisplay}.</p></form>);
}
