import { MessageCircle } from "lucide-react";
import { waLink } from "@/config/site";
export default function WhatsAppFloat() {
  return (<a href={waLink()} target="_blank" rel="noopener noreferrer" aria-label="تواصل عبر واتساب"
    className="fixed bottom-5 start-5 z-50 flex items-center gap-2 rounded-full bg-[#25D366] text-white px-4 py-3 font-semibold shadow-lg min-h-11">
    <MessageCircle size={22} aria-hidden />واتساب</a>);
}
