# موقع مكتب الأستاذ رأفت خضر المحامي بالنقض
تشغيل: `npm install && npm run dev` ثم افتح http://localhost:3000
النشر: ارفع المجلد على GitHub ثم اربطه بـ Vercel، وأضف الدومين من Settings > Domains.
عدّل `src/config/site.ts` (الدومين، البريد، رابط الخريطة) قبل النشر.
