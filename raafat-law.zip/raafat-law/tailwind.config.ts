import type { Config } from "tailwindcss";
export default { content:["./src/**/*.{ts,tsx}"],
theme:{extend:{colors:{navy:"#101D32",gold:"#B99A58",ivory:"#F3F1EC",ink:"#333333"},fontFamily:{sans:["var(--font-cairo)","Tahoma","sans-serif"]}}},plugins:[]} satisfies Config;
